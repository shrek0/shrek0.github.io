#!/usr/bin/env python

from threading import Thread
import subprocess
from time import sleep
from sys import exit


def thread_main(ip):
	ret = subprocess.call("ping -s 10000 %s" % ip, 
		shell=True, 
		stdout=open('/dev/null', 'w'), 
		stderr=subprocess.STDOUT)
	
def main(threads_count, time, ip):
	time *= 60
	
	for i in range(threads_count):
		thread = Thread(target=thread_main, args=([ip]))
		thread.start()
	
	sleep(time)
	exit(0)
	
if __name__=='__main__':
	main(5, 10, '127.0.0.1') # 5 threads and 10 minutes. 